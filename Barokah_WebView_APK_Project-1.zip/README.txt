BAROKAH WEBVIEW APK

Target:
http://127.0.0.1:8080/login.php

PENTING:
AWebServer harus berjalan di HP yang sama sebelum APK dibuka.

Cara build:
1. Upload project ini ke GitHub.
2. Buka tab Actions.
3. Pilih "Build Barokah APK".
4. Tekan "Run workflow".
5. Setelah selesai, buka hasil Artifact "Barokah-debug-apk".
6. Ambil app-debug.apk dan install di HP.

Catatan:
Aplikasi menggunakan cleartext HTTP karena server Barokah berjalan di localhost.
